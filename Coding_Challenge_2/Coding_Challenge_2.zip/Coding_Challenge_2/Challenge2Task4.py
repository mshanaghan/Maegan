# Ask user for an input of their current age
age = input("What is your age?")
print("Your age is: " + age)

# # Tell user how many years until they reach retirement
age = int(age)
print(f'You entered {age} so you are {65 - age} years from retirement.')

# This took me a while. Help from askpython.com